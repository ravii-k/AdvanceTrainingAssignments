import java.util.Scanner;

public class CmdFibonnocci {
    
    public static void main(String[] args) {
        int a,b,l=12;
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("number 1 : ");
            a=sc.nextInt();
            System.out.print("number 2 : ");
            b=sc.nextInt();
            System.out.println("Next 13 numbers after "+a+", "+b+ " are : ");
            System.out.println(a+"\n"+b);
        }
        for(int i=0; i<=l;i++)
        {
            int c= (a+b);
            System.out.print(c);
            System.out.print("\n");
            a=b;
            b=c;
        }
    }
}
