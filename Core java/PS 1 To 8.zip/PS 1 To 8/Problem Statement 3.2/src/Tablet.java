class Tablet extends Medicine {
	public void displayLabel() {
		System.out.println("store in a cool dry place");
	}
}