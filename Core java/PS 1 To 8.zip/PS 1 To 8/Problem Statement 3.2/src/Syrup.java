class Syrup extends Medicine {
	
	public void displayLabel()
	{
		System.out.println("Consumption as directed by thephysician");
	}
}