class Ointment extends Medicine 
{
	public void displayLabel() 
	{
		System.out.println("for external use only");
	}
}