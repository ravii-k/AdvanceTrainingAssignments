package AbstractClassInstrument;

class Piano extends Instrument {
	public void Play() {
		System.out.println("Piano is playing  tan tan tan tan");
	}
}