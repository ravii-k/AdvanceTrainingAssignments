package AbstractClassInstrument;

class Guitar extends Instrument {
	public void Play() {
		System.out.println("Guitar is playing  tin  tin  tin ");
	}
}