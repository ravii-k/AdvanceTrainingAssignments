package com.mycompany.domain;

public class Product {
	String productID;
	 String productName;
    double productPrice ;
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float product_price) {
		this.productPrice = productPrice;
	}
}
