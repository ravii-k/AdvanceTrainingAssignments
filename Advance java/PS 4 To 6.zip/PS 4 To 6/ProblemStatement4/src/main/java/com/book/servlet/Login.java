package com.book.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.book.dao.*;
import com.book.db.Connection1;
import com.book.entity.*;
import javax.servlet.http.HttpServlet;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String useruname=request.getParameter("uname");
		String userpassword=request.getParameter("pass");
		
		UserDao dao= new UserDao(Connection1.getConnection());
		
		User u=dao.getUserByUnameAndPassword(useruname, userpassword);
		
		if(u==null) {
			
			out.println("Invalid Information!!.. Try again");
			
			HttpSession s=request.getSession();
			
			response.sendRedirect("Login.jsp");
			
			
		}
		else {
			HttpSession s=request.getSession();
			s.setAttribute("currentUser", u);
			response.sendRedirect("Welcome.jsp");
			
		}
		
		
		
		
	}
}
