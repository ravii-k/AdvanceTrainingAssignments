package com.book.entity;

import java.sql.Timestamp;

public class User {
	String firstName;
	String address;
	String email;
	String uname;
	String pass;
	Timestamp regdate;
	
	public User() {
	}
	public User(String firstName, String address, String email, String uname, String pass, Timestamp regdate) {
		this.firstName = firstName;
		this.address = address;
		this.email = email;
		this.uname = uname;
		this.pass = pass;
		this.regdate = regdate;
	}
	
	public User(String firstName, String address, String email, String uname, String pass) {
		super();
		this.firstName = firstName;
		this.address = address;
		this.email = email;
		this.uname = uname;
		this.pass = pass;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Timestamp getRegdate() {
		return regdate;
	}
	public void setRegdate(Timestamp regdate) {
		this.regdate = regdate;
	}
	@Override
	public String toString() {
		return "User [first_name=" + firstName + ", address=" + address + ", email=" + email + ", uname=" + uname
				+ ", pass=" + pass + ", regdate=" + regdate + "]";
	}
	
}
