package com.book.entity;

public class Book {
	String BookId;
	String BookName;
	String Author;
	Double Price;

	public Book() {
	}

	public Book(String bookId, String bookName, String author, Double price) {
		super();
		this.BookId = bookId;
		this.BookName = bookName;
		this.Author = author;
		this.Price = price;
	}

	public String getBookId() {
		return BookId;
	}

	public void setBookId(String bookId) {
		this.BookId = bookId;
	}

	public String getBookName() {
		return BookName;
	}

	public void setBookName(String bookName) {
		BookName = bookName;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public Double getPrice() {
		return Price;
	}

	public void setPrice(Double price) {
		Price = price;
	}

	@Override
	public String toString() {
		return "Books [Book_id=" + BookId + ", Book_name=" + BookName + ", Author=" + Author + ", Price=" + Price
				+ "]";
	}

}
