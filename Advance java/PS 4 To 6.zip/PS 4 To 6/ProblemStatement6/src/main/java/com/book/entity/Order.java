package com.book.entity;

import java.security.Timestamp;

public class Order {
	
	String address;
	int mobileno;
	String name;
	Timestamp orderdate;
	int quantity;
	
	public Order(String address, int mobileno, String name) {
		super();
		this.address = address;
		this.mobileno = mobileno;
		this.name = name;
	}
	public Order(int orderId, String address, int mobileno, String name,int quantity) {
		super();
		this.orderId = orderId;
		this.address = address;
		this.mobileno = mobileno;
		this.name = name;
		this.quantity = quantity;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getMobileno() {
		return mobileno;
	}
	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Timestamp getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Timestamp orderdate) {
		this.orderdate = orderdate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	int orderId;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	@Override
	public String toString() {
		return "Orders [order_id=" + orderId + ", address=" + address + ", mobileno=" + mobileno + ", name=" + name
				+ ", orderdate=" + orderdate + ", quantity=" + quantity + "]";
	}

	
	
}
